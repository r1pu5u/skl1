<?php 

$conn = mysqli_connect("localhost","root","","lks");

// var_dump($conn);

function query($query) {
    global $conn;
    $result = mysqli_query($conn, $query);
    $rows = [];

    while ( $row = mysqli_fetch_assoc($result) ) {
        $rows[] = $row;
    }

    return $rows;
}

function cari($keyword) {
	$query = "SELECT * FROM  WHERE  LIKE '%$keyword%'";
	return query($query);
}

function tambah($data) {
	global $conn;

	

	// cek gambar di upload
	$gambar = upload();
		if( !$gambar  ) {
			return false;
		}


	$query = "";

	return mysqli_affected_rows($conn);
	
}

function upload() {
    $namaGambar = $_FILES['gambar']['name'];
    $tempatGambar = $_FILES['gambar']['tmp_name'];
    $error = $_FILES['gambar']['error'];
    $sizeGambar = $_FILES['gambar']['size'];
    
if($error != "4") {

        $ekstensi_diperbolehkan = array('png','jpg','jpeg');
          $x = explode('.', $namaGambar);
          $ekstensi = strtolower(end($x));
          

          if(in_array($ekstensi, $ekstensi_diperbolehkan) === true) {
              move_uploaded_file($tempatGambar, '../../images/thumbs/post/'.$namaGambar);
              return $namaGambar;
          }else {
              echo "<script>alert('cek ekstensi gambar anda')</script>";
          }
}else {
    echo "<script>alert('pilih gambar terlebih dahulu')</script>";
}
}

function ubah($data) {
	global $conn;

	$id = $data["id"];
	$judul = htmlspecialchars($data["judul"]);
	$keterangan = htmlspecialchars($data["keterangan"]);
	$kategori = htmlspecialchars($data["kategori"]);
	$tanggal = htmlspecialchars($data["tanggal"]);
	$gambarLama = htmlspecialchars($data["gambarLama"]);
	$artikelLama = htmlspecialchars($data["artikelLama"]);

	if( $_FILES['gambar']['error'] === 4 ) {
		$gambar = $gambarLama;
	} else {
		unlink('../../images/thumbs/post/'. $gambarLama);
		$gambar = upload();
	}

	
	


	$query = "UPDATE ";

	mysqli_query($conn, $query);


	return mysqli_affected_rows($conn);
}
