<?php 

$conn = mysqli_connect("localhost","root","","lks");

// var_dump($conn);

function query($query) {
    global $conn;
    $result = mysqli_query($conn, $query);
    $rows = [];

    while ( $row = mysqli_fetch_assoc($result) ) {
        $rows[] = $row;
    }

    return $rows;
}

function tambah_employee($data) {
    global $conn;
    $id = rand(100, 10000);
    $name = mysqli_real_escape_string($conn, htmlspecialchars($data['name']));
    $email = mysqli_real_escape_string($conn, htmlspecialchars($data['email']));
    $handphone = mysqli_real_escape_string($conn, htmlspecialchars($data['handphone']));
    $position = mysqli_real_escape_string($conn, htmlspecialchars($data['position']));
    $query = "INSERT INTO `msemployee` (`employeeid`, `name`, `email`, `password`, `handphone`, `position`) 
    VALUES ('$id', '$name', '$email', '$handphone', '', '$position') ";
    mysqli_query($conn, $query);
    return mysqli_affected_rows($conn);
}



?>