$(document).ready(function() {
    $('#sidebarCollapse').on('click', function() {
      $('#sidebar, #content').toggleClass('active');
      $('.collapse.in').toggleClass('in');
      $('a[aria-expanded=true]').attr('aria-expanded', 'false');
      document.getElementById("bodyContent").style.width="100%";
    });

    $("#hideme").hide(); 
    $(document).on('click', '.edit', function (e) {
        var employeeid = $(this).data('employeeid');
        var name = $(this).data('name');
        var email = $(this).data('email');
        var handphone = $(this).data('handphone');
        var position = $(this).data('position');

        console.log(employeeid);

        e.preventDefault();
        $('#form-employeeid').val(employeeid);
        $('#form-name').val(name);
        $('#form-email').val(email);
        $('#form-handphone').val(handphone);
        $('#form-position').val(position);
        $("#tombol").html('Update');
        $("#tombol").attr('name', 'update');
        $("#lab-pswd").html('New password');
        $("#pswd").attr('name', 'new_password');
        $("#hideme").show(200);
    })

    $('#reset').on('click', function() {
      $('#form-employeeid').val('');
      $('#form-name').val('');
      $('#form-email').val('');
      $('#form-handphone').val('');
      $('#form-position').val('');
      $("#tombol").html('Insert');
      $("#tombol").attr('name', 'insert');
      $("#lab-pswd").html('password');
      $("#hideme").hide();
    });

    
});